# PyCharm Test

# Replace the abc123 with your uni
uni = "abc123"

print(uni)
print("Hello World!")